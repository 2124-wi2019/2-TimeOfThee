/*
Timothy Washington
washington_a03c.js
INFO 2124 - Javascript I
Thoendel
Creation date: Dec 22, 2019
*/
//comment Legend: {c=creates variable, s=sets a variable to a value}
var a="When in the ecourse of human events";//cs
console.log(`The preamble is:
\t${a}

Does the preamble contain 'a'?
\t${a.includes('a')}`)
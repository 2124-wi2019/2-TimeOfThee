/*
Timothy Washington
washington_a02b.js
INFO 2124 - Javascript I
Thoendel
Creation date: Dec 15, 2019
*/
//Capitalization of values is not important. If the goal is to learn about variables, I'm assuming accuracy isn't either
let nam='Timothy Washington';
var age=20;
const har='Multipule shades of the exact same brown';
const eye='The guy in the mirror will not tell me';
console.log();
console.log("My name:");
console.log(nam);
console.log("My age:");
console.log(age);
console.log("My Hair Color:");
console.log(har);
console.log("My Eye Color:");
console.log(eye);
console.log();
